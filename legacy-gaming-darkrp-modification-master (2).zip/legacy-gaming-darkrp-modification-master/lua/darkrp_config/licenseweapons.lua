--[[---------------------------------------------------------------------------
License weapons
Add weapons that do NOT require a special license here
ALL other weapons will require a license

Note: this only works if the license setting is enabled
---------------------------------------------------------------------------]]
GM.NoLicense["weapon_physcannon"] = true
GM.NoLicense["weapon_physgun"]    = true
GM.NoLicense["weapon_bugbait"]    = true
GM.NoLicense["gmod_tool"]         = true
GM.NoLicense["gmod_camera"]       = true
